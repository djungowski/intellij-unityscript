class LightmapBakeQuality {



}