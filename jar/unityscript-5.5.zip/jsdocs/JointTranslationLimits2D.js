class JointTranslationLimits2D {


    /**
     * Maximum distance the Rigidbody2D object can move from the Slider Joint&#039;s anchor.
     */
    get max() {}

    /**
     * Maximum distance the Rigidbody2D object can move from the Slider Joint&#039;s anchor.
     */
    set max(value) {}

    /**
     * Minimum distance the Rigidbody2D object can move from the Slider Joint&#039;s anchor.
     */
    get min() {}

    /**
     * Minimum distance the Rigidbody2D object can move from the Slider Joint&#039;s anchor.
     */
    set min(value) {}


}