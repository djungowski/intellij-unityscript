class GUILayoutUtility {

    /**
     * Reserve layout space for a rectangle with a specific aspect ratio.
     */
    static GetAspectRect() {}

    /**
     * Get the rectangle last used by GUILayout for a control.
     */
    static GetLastRect() {}

    /**
     * Reserve layout space for a rectangle for displaying some contents with a specific style.
     */
    static GetRect() {}



}