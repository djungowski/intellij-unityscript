class HorizontalWrapMode {


    /**
     * Text will word-wrap when reaching the horizontal boundary.
     */
    get Wrap() {}

    /**
     * Text will word-wrap when reaching the horizontal boundary.
     */
    set Wrap(value) {}

    /**
     * Text can exceed the horizontal boundary.
     */
    get Overflow() {}

    /**
     * Text can exceed the horizontal boundary.
     */
    set Overflow(value) {}


}