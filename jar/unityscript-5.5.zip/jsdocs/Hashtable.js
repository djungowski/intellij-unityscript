class Hashtable {


    /**
     * Returns how many elements are in the hashtable.
     */
    get Count() {}

    /**
     * Returns how many elements are in the hashtable.
     */
    set Count(value) {}


    /**
     * Adds an element with the specified key and value into the Hashtable.
     */
    Add() {}

    /**
     * Count is set to zero, and references to other objects from elements of the collection are also released.
     */
    Clear() {}

    /**
     * Determines whether the Hashtable contains a specific key.
     */
    Contains() {}

    /**
     * Determines whether the Hashtable contains a specific key.
     */
    ContainsKey() {}

    /**
     * Determines whether the Hashtable contains a specific value.
     */
    ContainsValue() {}

    /**
     * Removes the element with the specified key from the Hashtable.
     */
    Remove() {}

}