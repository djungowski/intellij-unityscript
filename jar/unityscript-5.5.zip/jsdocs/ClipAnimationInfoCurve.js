class ClipAnimationInfoCurve {


    /**
     * The animation curve.
     */
    get curve() {}

    /**
     * The animation curve.
     */
    set curve(value) {}

    /**
     * The name of the animation curve.
     */
    get name() {}

    /**
     * The name of the animation curve.
     */
    set name(value) {}


}