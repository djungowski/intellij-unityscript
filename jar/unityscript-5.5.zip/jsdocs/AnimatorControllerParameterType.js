class AnimatorControllerParameterType {


    /**
     * Float type parameter.
     */
    get Float() {}

    /**
     * Float type parameter.
     */
    set Float(value) {}

    /**
     * Int type parameter.
     */
    get Int() {}

    /**
     * Int type parameter.
     */
    set Int(value) {}

    /**
     * Boolean type parameter.
     */
    get Bool() {}

    /**
     * Boolean type parameter.
     */
    set Bool(value) {}

    /**
     * Trigger type parameter.
     */
    get Trigger() {}

    /**
     * Trigger type parameter.
     */
    set Trigger(value) {}


}