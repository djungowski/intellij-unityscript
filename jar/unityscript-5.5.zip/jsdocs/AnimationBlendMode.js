class AnimationBlendMode {


    /**
     * Animations will be blended.
     */
    get Blend() {}

    /**
     * Animations will be blended.
     */
    set Blend(value) {}

    /**
     * Animations will be added.
     */
    get Additive() {}

    /**
     * Animations will be added.
     */
    set Additive(value) {}


}