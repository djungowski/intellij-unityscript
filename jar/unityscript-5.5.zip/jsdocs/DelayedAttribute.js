class DelayedAttribute {


    /**
     * Optional field to specify the order that multiple DecorationDrawers should be drawn in.
     */
    get order() {}

    /**
     * Optional field to specify the order that multiple DecorationDrawers should be drawn in.
     */
    set order(value) {}


}