class ModelImporterNormals {


    /**
     * Import vertex normals from model file (default).
     */
    get Import() {}

    /**
     * Import vertex normals from model file (default).
     */
    set Import(value) {}

    /**
     * Calculate vertex normals.
     */
    get Calculate() {}

    /**
     * Calculate vertex normals.
     */
    set Calculate(value) {}

    /**
     * Do not import vertex normals.
     */
    get None() {}

    /**
     * Do not import vertex normals.
     */
    set None(value) {}


}