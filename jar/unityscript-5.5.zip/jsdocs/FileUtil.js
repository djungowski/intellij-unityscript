class FileUtil {

    /**
     * Copies a file or a directory.
     */
    static CopyFileOrDirectory() {}

    /**
     * Copies the file or directory.
     */
    static CopyFileOrDirectoryFollowSymlinks() {}

    /**
     * Deletes a file or a directory given a path.
     */
    static DeleteFileOrDirectory() {}

    /**
     * Returns a unique path in the Temp folder within your current project.
     */
    static GetUniqueTempPathInProject() {}

    /**
     * Moves a file or a directory from a given path to another path.
     */
    static MoveFileOrDirectory() {}

    /**
     * Replaces a directory.
     */
    static ReplaceDirectory() {}

    /**
     * Replaces a file.
     */
    static ReplaceFile() {}



}