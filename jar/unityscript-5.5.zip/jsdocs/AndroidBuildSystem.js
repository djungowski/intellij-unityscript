class AndroidBuildSystem {


    /**
     * Build APK using internal build system.
     */
    get Internal() {}

    /**
     * Build APK using internal build system.
     */
    set Internal(value) {}

    /**
     * Build APK using Gradle or export Gradle project.
     */
    get Gradle() {}

    /**
     * Build APK using Gradle or export Gradle project.
     */
    set Gradle(value) {}

    /**
     * Export ADT (legacy) project.
     */
    get ADT() {}

    /**
     * Export ADT (legacy) project.
     */
    set ADT(value) {}


}