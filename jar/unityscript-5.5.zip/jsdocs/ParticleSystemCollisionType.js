class ParticleSystemCollisionType {


    /**
     * Collide with a list of planes.
     */
    get Planes() {}

    /**
     * Collide with a list of planes.
     */
    set Planes(value) {}

    /**
     * Collide with the world geometry.
     */
    get World() {}

    /**
     * Collide with the world geometry.
     */
    set World(value) {}


}