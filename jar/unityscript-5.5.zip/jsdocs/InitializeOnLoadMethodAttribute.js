class InitializeOnLoadMethodAttribute {



}