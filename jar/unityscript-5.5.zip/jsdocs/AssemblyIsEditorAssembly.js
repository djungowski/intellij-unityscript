class AssemblyIsEditorAssembly {



}