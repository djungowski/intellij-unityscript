class ParticleSystemCustomData {


    /**
     * The first stream of custom per-particle data.
     */
    get Custom1() {}

    /**
     * The first stream of custom per-particle data.
     */
    set Custom1(value) {}

    /**
     * The second stream of custom per-particle data.
     */
    get Custom2() {}

    /**
     * The second stream of custom per-particle data.
     */
    set Custom2(value) {}


}