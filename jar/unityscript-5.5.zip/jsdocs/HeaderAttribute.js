class HeaderAttribute {


    /**
     * The header text.
     */
    get header() {}

    /**
     * The header text.
     */
    set header(value) {}

    /**
     * Optional field to specify the order that multiple DecorationDrawers should be drawn in.
     */
    get order() {}

    /**
     * Optional field to specify the order that multiple DecorationDrawers should be drawn in.
     */
    set order(value) {}


}