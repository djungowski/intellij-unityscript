class ClusterNetwork {
    /**
     * Check whether the current instance is disconnected from the cluster network.
     */
    static get isDisconnected() {}

    /**
     * Check whether the current instance is disconnected from the cluster network.
     */
    static set isDisconnected(value) {}

    /**
     * Check whether the current instance is a master node in the cluster network.
     */
    static get isMasterOfCluster() {}

    /**
     * Check whether the current instance is a master node in the cluster network.
     */
    static set isMasterOfCluster(value) {}

    /**
     * To acquire or set the node index of the current machine from the cluster network.
     */
    static get nodeIndex() {}

    /**
     * To acquire or set the node index of the current machine from the cluster network.
     */
    static set nodeIndex(value) {}




}