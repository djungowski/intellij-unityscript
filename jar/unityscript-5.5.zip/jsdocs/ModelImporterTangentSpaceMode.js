class ModelImporterTangentSpaceMode {



}