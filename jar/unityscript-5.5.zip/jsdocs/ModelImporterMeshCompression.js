class ModelImporterMeshCompression {


    /**
     * No mesh compression (default).
     */
    get Off() {}

    /**
     * No mesh compression (default).
     */
    set Off(value) {}

    /**
     * Low amount of mesh compression.
     */
    get Low() {}

    /**
     * Low amount of mesh compression.
     */
    set Low(value) {}

    /**
     * Medium amount of mesh compression.
     */
    get Medium() {}

    /**
     * Medium amount of mesh compression.
     */
    set Medium(value) {}

    /**
     * High amount of mesh compression.
     */
    get High() {}

    /**
     * High amount of mesh compression.
     */
    set High(value) {}


}