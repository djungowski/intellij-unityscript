class Microphone {
    /**
     * A list of available microphone devices, identified by name.
     */
    static get devices() {}

    /**
     * A list of available microphone devices, identified by name.
     */
    static set devices(value) {}


    /**
     * Stops recording.
     */
    static End() {}

    /**
     * Get the frequency capabilities of a device.
     */
    static GetDeviceCaps() {}

    /**
     * Get the position in samples of the recording.
     */
    static GetPosition() {}

    /**
     * Query if a device is currently recording.
     */
    static IsRecording() {}

    /**
     * Start Recording with device.
     */
    static Start() {}



}