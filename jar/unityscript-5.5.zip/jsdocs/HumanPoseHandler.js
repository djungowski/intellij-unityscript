class HumanPoseHandler {



    /**
     * Gets a human pose from the handled avatar skeleton.
     */
    GetHumanPose() {}

    /**
     * Sets a human pose on the handled avatar skeleton.
     */
    SetHumanPose() {}

}