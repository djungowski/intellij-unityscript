class NonSerializable {



}