class Color32 {

    /**
     * Linearly interpolates between colors a and b by t.
     */
    static Lerp() {}

    /**
     * Linearly interpolates between colors a and b by t.
     */
    static LerpUnclamped() {}


    /**
     * Alpha component of the color.
     */
    get a() {}

    /**
     * Alpha component of the color.
     */
    set a(value) {}

    /**
     * Blue component of the color.
     */
    get b() {}

    /**
     * Blue component of the color.
     */
    set b(value) {}

    /**
     * Green component of the color.
     */
    get g() {}

    /**
     * Green component of the color.
     */
    set g(value) {}

    /**
     * Red component of the color.
     */
    get r() {}

    /**
     * Red component of the color.
     */
    set r(value) {}


    /**
     * Returns a nicely formatted string of this color.
     */
    ToString() {}

}