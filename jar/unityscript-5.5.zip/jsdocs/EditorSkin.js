class EditorSkin {


    /**
     * The skin used for game views.
     */
    get Game() {}

    /**
     * The skin used for game views.
     */
    set Game(value) {}

    /**
     * The skin used for inspectors.
     */
    get Inspector() {}

    /**
     * The skin used for inspectors.
     */
    set Inspector(value) {}

    /**
     * The skin used for scene views.
     */
    get Scene() {}

    /**
     * The skin used for scene views.
     */
    set Scene(value) {}


}