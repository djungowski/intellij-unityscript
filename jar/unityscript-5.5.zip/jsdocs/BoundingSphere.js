class BoundingSphere {


    /**
     * The position of the center of the BoundingSphere.
     */
    get position() {}

    /**
     * The position of the center of the BoundingSphere.
     */
    set position(value) {}

    /**
     * The radius of the BoundingSphere.
     */
    get radius() {}

    /**
     * The radius of the BoundingSphere.
     */
    set radius(value) {}


}