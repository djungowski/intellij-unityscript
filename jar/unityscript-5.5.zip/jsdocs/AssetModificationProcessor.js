class AssetModificationProcessor {



}