class PreferBinarySerialization {



}