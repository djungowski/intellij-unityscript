class JointProjectionMode {


    /**
     * Don&#039;t snap at all.
     */
    get None() {}

    /**
     * Don&#039;t snap at all.
     */
    set None(value) {}

    /**
     * Snap both position and rotation.
     */
    get PositionAndRotation() {}

    /**
     * Snap both position and rotation.
     */
    set PositionAndRotation(value) {}


}