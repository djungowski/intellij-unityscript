class MenuCommand {


    /**
     * Context is the object that is the target of a menu command.
     */
    get context() {}

    /**
     * Context is the object that is the target of a menu command.
     */
    set context(value) {}

    /**
     * An integer for passing custom information to a menu item.
     */
    get userData() {}

    /**
     * An integer for passing custom information to a menu item.
     */
    set userData(value) {}


}