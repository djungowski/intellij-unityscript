class ModelImporterMaterialSearch {


    /**
     * Search in local Materials folder.
     */
    get Local() {}

    /**
     * Search in local Materials folder.
     */
    set Local(value) {}

    /**
     * Recursive-up search in Materials folders.
     */
    get RecursiveUp() {}

    /**
     * Recursive-up search in Materials folders.
     */
    set RecursiveUp(value) {}

    /**
     * Search in all project.
     */
    get Everywhere() {}

    /**
     * Search in all project.
     */
    set Everywhere(value) {}


}