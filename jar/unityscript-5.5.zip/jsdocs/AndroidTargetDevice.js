class AndroidTargetDevice {


    /**
     * All supported architectures.
     */
    get FAT() {}

    /**
     * All supported architectures.
     */
    set FAT(value) {}

    /**
     * ARMv7 only.
     */
    get ARMv7() {}

    /**
     * ARMv7 only.
     */
    set ARMv7(value) {}

    /**
     * Intel only.
     */
    get x86() {}

    /**
     * Intel only.
     */
    set x86(value) {}


}