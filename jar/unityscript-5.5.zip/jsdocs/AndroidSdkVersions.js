class AndroidSdkVersions {


    /**
     * Android 2.3.1, &quot;Gingerbread&quot;, API level 9.
     */
    get AndroidApiLevel9() {}

    /**
     * Android 2.3.1, &quot;Gingerbread&quot;, API level 9.
     */
    set AndroidApiLevel9(value) {}

    /**
     * Android 2.3.3, &quot;Gingerbread&quot;, API level 10.
     */
    get AndroidApiLevel10() {}

    /**
     * Android 2.3.3, &quot;Gingerbread&quot;, API level 10.
     */
    set AndroidApiLevel10(value) {}

    /**
     * Android 3.0, &quot;Honeycomb&quot;, API level 11.
     */
    get AndroidApiLevel11() {}

    /**
     * Android 3.0, &quot;Honeycomb&quot;, API level 11.
     */
    set AndroidApiLevel11(value) {}

    /**
     * Android 3.1, &quot;Honeycomb&quot;, API level 12.
     */
    get AndroidApiLevel12() {}

    /**
     * Android 3.1, &quot;Honeycomb&quot;, API level 12.
     */
    set AndroidApiLevel12(value) {}

    /**
     * Android 3.2, &quot;Honeycomb&quot;, API level 13.
     */
    get AndroidApiLevel13() {}

    /**
     * Android 3.2, &quot;Honeycomb&quot;, API level 13.
     */
    set AndroidApiLevel13(value) {}

    /**
     * Android 4.0, &quot;Ice Cream Sandwich&quot;, API level 14.
     */
    get AndroidApiLevel14() {}

    /**
     * Android 4.0, &quot;Ice Cream Sandwich&quot;, API level 14.
     */
    set AndroidApiLevel14(value) {}

    /**
     * Android 4.0.3, &quot;Ice Cream Sandwich&quot;, API level 15.
     */
    get AndroidApiLevel15() {}

    /**
     * Android 4.0.3, &quot;Ice Cream Sandwich&quot;, API level 15.
     */
    set AndroidApiLevel15(value) {}

    /**
     * Android 4.1, &quot;Jelly Bean&quot;, API level 16.
     */
    get AndroidApiLevel16() {}

    /**
     * Android 4.1, &quot;Jelly Bean&quot;, API level 16.
     */
    set AndroidApiLevel16(value) {}

    /**
     * Android 4.2, &quot;Jelly Bean&quot;, API level 17.
     */
    get AndroidApiLevel17() {}

    /**
     * Android 4.2, &quot;Jelly Bean&quot;, API level 17.
     */
    set AndroidApiLevel17(value) {}

    /**
     * Android 4.3, &quot;Jelly Bean&quot;, API level 18.
     */
    get AndroidApiLevel18() {}

    /**
     * Android 4.3, &quot;Jelly Bean&quot;, API level 18.
     */
    set AndroidApiLevel18(value) {}

    /**
     * Android 4.4, &quot;KitKat&quot;, API level 19.
     */
    get AndroidApiLevel19() {}

    /**
     * Android 4.4, &quot;KitKat&quot;, API level 19.
     */
    set AndroidApiLevel19(value) {}

    /**
     * Android 5.0, &quot;Lollipop&quot;, API level 21.
     */
    get AndroidApiLevel21() {}

    /**
     * Android 5.0, &quot;Lollipop&quot;, API level 21.
     */
    set AndroidApiLevel21(value) {}

    /**
     * Android 5.1, &quot;Lollipop&quot;, API level 22.
     */
    get AndroidApiLevel22() {}

    /**
     * Android 5.1, &quot;Lollipop&quot;, API level 22.
     */
    set AndroidApiLevel22(value) {}


}