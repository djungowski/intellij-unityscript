class ProceduralCacheSize {


    /**
     * A limit of 128MB for the cache or the working memory.
     */
    get Tiny() {}

    /**
     * A limit of 128MB for the cache or the working memory.
     */
    set Tiny(value) {}

    /**
     * A limit of 256MB for the cache or the working memory.
     */
    get Medium() {}

    /**
     * A limit of 256MB for the cache or the working memory.
     */
    set Medium(value) {}

    /**
     * A limit of 512MB for the cache or the working memory.
     */
    get Heavy() {}

    /**
     * A limit of 512MB for the cache or the working memory.
     */
    set Heavy(value) {}

    /**
     * No limit for the cache or the working memory.
     */
    get NoLimit() {}

    /**
     * No limit for the cache or the working memory.
     */
    set NoLimit(value) {}

    /**
     * A limit of 1B (one byte) for the cache or the working memory.
     */
    get None() {}

    /**
     * A limit of 1B (one byte) for the cache or the working memory.
     */
    set None(value) {}


}