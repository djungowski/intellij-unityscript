class ICanvasRaycastFilter {



    /**
     * Given a point and a camera is the raycast valid.
     */
    IsRaycastLocationValid() {}

}