class JointSpring {


    /**
     * The damper force uses to dampen the spring.
     */
    get damper() {}

    /**
     * The damper force uses to dampen the spring.
     */
    set damper(value) {}

    /**
     * The spring forces used to reach the target position.
     */
    get spring() {}

    /**
     * The spring forces used to reach the target position.
     */
    set spring(value) {}

    /**
     * The target position the joint attempts to reach.
     */
    get targetPosition() {}

    /**
     * The target position the joint attempts to reach.
     */
    set targetPosition(value) {}


}