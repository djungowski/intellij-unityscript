class ApiCompatibilityLevel {


    /**
     * .NET 2.0.
     */
    get NET_2_0() {}

    /**
     * .NET 2.0.
     */
    set NET_2_0(value) {}

    /**
     * .NET 2.0 Subset.
     */
    get NET_2_0_Subset() {}

    /**
     * .NET 2.0 Subset.
     */
    set NET_2_0_Subset(value) {}


}