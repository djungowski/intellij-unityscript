class CollisionFlags {


    /**
     * CollisionFlags is a bitmask returned by CharacterController.Move.
     */
    get None() {}

    /**
     * CollisionFlags is a bitmask returned by CharacterController.Move.
     */
    set None(value) {}

    /**
     * CollisionFlags is a bitmask returned by CharacterController.Move.
     */
    get Sides() {}

    /**
     * CollisionFlags is a bitmask returned by CharacterController.Move.
     */
    set Sides(value) {}

    /**
     * CollisionFlags is a bitmask returned by CharacterController.Move.
     */
    get Above() {}

    /**
     * CollisionFlags is a bitmask returned by CharacterController.Move.
     */
    set Above(value) {}

    /**
     * CollisionFlags is a bitmask returned by CharacterController.Move.
     */
    get Below() {}

    /**
     * CollisionFlags is a bitmask returned by CharacterController.Move.
     */
    set Below(value) {}


}