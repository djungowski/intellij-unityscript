class GraphicsJobMode {


    /**
     * Native graphics jobs.
     */
    get Native() {}

    /**
     * Native graphics jobs.
     */
    set Native(value) {}

    /**
     * Legacy graphics jobs.
     */
    get Legacy() {}

    /**
     * Legacy graphics jobs.
     */
    set Legacy(value) {}


}