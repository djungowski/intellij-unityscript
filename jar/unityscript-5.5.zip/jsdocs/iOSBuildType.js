class iOSBuildType {


    /**
     * Build configuration set to Debug for the generated Xcode project.
     */
    get Debug() {}

    /**
     * Build configuration set to Debug for the generated Xcode project.
     */
    set Debug(value) {}

    /**
     * Build configuration set to Release for the generated Xcode project with optimization enabled.
     */
    get Release() {}

    /**
     * Build configuration set to Release for the generated Xcode project with optimization enabled.
     */
    set Release(value) {}


}