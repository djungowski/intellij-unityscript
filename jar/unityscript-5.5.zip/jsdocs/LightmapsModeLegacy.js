class LightmapsModeLegacy {


    /**
     * Single, traditional lightmap rendering mode.
     */
    get Single() {}

    /**
     * Single, traditional lightmap rendering mode.
     */
    set Single(value) {}

    /**
     * Dual lightmap rendering mode.
     */
    get Dual() {}

    /**
     * Dual lightmap rendering mode.
     */
    set Dual(value) {}

    /**
     * Directional rendering mode.
     */
    get Directional() {}

    /**
     * Directional rendering mode.
     */
    set Directional(value) {}


}