class CanEditMultipleObjects {



}