class JointMotor {


    /**
     * The motor will apply a force.
     */
    get force() {}

    /**
     * The motor will apply a force.
     */
    set force(value) {}

    /**
     * If freeSpin is enabled the motor will only accelerate but never slow down.
     */
    get freeSpin() {}

    /**
     * If freeSpin is enabled the motor will only accelerate but never slow down.
     */
    set freeSpin(value) {}

    /**
     * The motor will apply a force up to force to achieve targetVelocity.
     */
    get targetVelocity() {}

    /**
     * The motor will apply a force up to force to achieve targetVelocity.
     */
    set targetVelocity(value) {}


}