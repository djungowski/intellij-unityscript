class AudioSourceCurveType {


    /**
     * Custom Volume Rolloff.
     */
    get CustomRolloff() {}

    /**
     * Custom Volume Rolloff.
     */
    set CustomRolloff(value) {}

    /**
     * The Spatial Blend.
     */
    get SpatialBlend() {}

    /**
     * The Spatial Blend.
     */
    set SpatialBlend(value) {}

    /**
     * Reverb Zone Mix.
     */
    get ReverbZoneMix() {}

    /**
     * Reverb Zone Mix.
     */
    set ReverbZoneMix(value) {}

    /**
     * The 3D Spread.
     */
    get Spread() {}

    /**
     * The 3D Spread.
     */
    set Spread(value) {}


}