class AnimatorClipInfo {


    /**
     * Returns the animation clip played by the Animator.
     */
    get clip() {}

    /**
     * Returns the animation clip played by the Animator.
     */
    set clip(value) {}

    /**
     * Returns the blending weight used by the Animator to blend this clip.
     */
    get weight() {}

    /**
     * Returns the blending weight used by the Animator to blend this clip.
     */
    set weight(value) {}


}