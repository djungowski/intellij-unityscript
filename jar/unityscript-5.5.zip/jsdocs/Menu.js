class Menu {

    /**
     * Get the check status of the given menu.
     */
    static GetChecked() {}

    /**
     * Set the check status of the given menu.
     */
    static SetChecked() {}



}