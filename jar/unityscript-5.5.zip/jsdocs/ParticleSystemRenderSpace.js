class ParticleSystemRenderSpace {


    /**
     * Particles face the camera plane.
     */
    get View() {}

    /**
     * Particles face the camera plane.
     */
    set View(value) {}

    /**
     * Particles align with the world.
     */
    get World() {}

    /**
     * Particles align with the world.
     */
    set World(value) {}

    /**
     * Particles align with their local transform.
     */
    get Local() {}

    /**
     * Particles align with their local transform.
     */
    set Local(value) {}

    /**
     * Particles face the eye position.
     */
    get Facing() {}

    /**
     * Particles face the eye position.
     */
    set Facing(value) {}


}