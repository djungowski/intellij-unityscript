class AvatarIKHint {


    /**
     * The left knee IK hint.
     */
    get LeftKnee() {}

    /**
     * The left knee IK hint.
     */
    set LeftKnee(value) {}

    /**
     * The right knee IK hint.
     */
    get RightKnee() {}

    /**
     * The right knee IK hint.
     */
    set RightKnee(value) {}

    /**
     * The left elbow IK hint.
     */
    get LeftElbow() {}

    /**
     * The left elbow IK hint.
     */
    set LeftElbow(value) {}

    /**
     * The right elbow IK hint.
     */
    get RightElbow() {}

    /**
     * The right elbow IK hint.
     */
    set RightElbow(value) {}


}