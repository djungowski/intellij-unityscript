class FontStyle {


    /**
     * No special style is applied.
     */
    get Normal() {}

    /**
     * No special style is applied.
     */
    set Normal(value) {}

    /**
     * Bold style applied to your texts.
     */
    get Bold() {}

    /**
     * Bold style applied to your texts.
     */
    set Bold(value) {}

    /**
     * Italic style applied to your texts.
     */
    get Italic() {}

    /**
     * Italic style applied to your texts.
     */
    set Italic(value) {}

    /**
     * Bold and Italic styles applied to your texts.
     */
    get BoldAndItalic() {}

    /**
     * Bold and Italic styles applied to your texts.
     */
    set BoldAndItalic(value) {}


}