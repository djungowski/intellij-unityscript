class Help {

    /**
     * Open url in the default web browser.
     */
    static BrowseURL() {}

    /**
     * Get the URL for this object&#039;s documentation.
     */
    static GetHelpURLForObject() {}

    /**
     * Is there a help page for this object?
     */
    static HasHelpForObject() {}

    /**
     * Show help page for this object.
     */
    static ShowHelpForObject() {}

    /**
     * Show a help page.
     */
    static ShowHelpPage() {}



}