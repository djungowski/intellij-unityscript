class ColorUtility {

    /**
     * Returns the color as a hexadecimal string in the format &quot;RRGGBB&quot;.
     */
    static ToHtmlStringRGB() {}

    /**
     * Returns the color as a hexadecimal string in the format &quot;RRGGBBAA&quot;.
     */
    static ToHtmlStringRGBA() {}

    /**
     * Attempts to convert a html color string.
     */
    static TryParseHtmlString() {}



}