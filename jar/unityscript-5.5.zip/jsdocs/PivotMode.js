class PivotMode {


    /**
     * The tool handle is at the graphical center of the selection.
     */
    get Center() {}

    /**
     * The tool handle is at the graphical center of the selection.
     */
    set Center(value) {}

    /**
     * The tool handle is on the pivot point of the active object.
     */
    get Pivot() {}

    /**
     * The tool handle is on the pivot point of the active object.
     */
    set Pivot(value) {}


}