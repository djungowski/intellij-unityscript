class ForceMode2D {


    /**
     * Add a force to the Rigidbody2D, using its mass.
     */
    get Force() {}

    /**
     * Add a force to the Rigidbody2D, using its mass.
     */
    set Force(value) {}

    /**
     * Add an instant force impulse to the rigidbody2D, using its mass.
     */
    get Impulse() {}

    /**
     * Add an instant force impulse to the rigidbody2D, using its mass.
     */
    set Impulse(value) {}


}