class AscentCalculationMode {


    /**
     * Legacy bounding box method.
     */
    get Legacy2x() {}

    /**
     * Legacy bounding box method.
     */
    set Legacy2x(value) {}

    /**
     * Ascender method.
     */
    get FaceAscender() {}

    /**
     * Ascender method.
     */
    set FaceAscender(value) {}

    /**
     * Bounding box method.
     */
    get FaceBoundingBox() {}

    /**
     * Bounding box method.
     */
    set FaceBoundingBox(value) {}


}