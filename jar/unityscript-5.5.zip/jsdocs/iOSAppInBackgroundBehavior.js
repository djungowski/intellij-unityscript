class iOSAppInBackgroundBehavior {


    /**
     * Custom background behavior, see iOSBackgroundMode for specific background modes.
     */
    get Custom() {}

    /**
     * Custom background behavior, see iOSBackgroundMode for specific background modes.
     */
    set Custom(value) {}

    /**
     * Application should suspend execution when entering background.
     */
    get Suspend() {}

    /**
     * Application should suspend execution when entering background.
     */
    set Suspend(value) {}

    /**
     * Application should exit when entering background.
     */
    get Exit() {}

    /**
     * Application should exit when entering background.
     */
    set Exit(value) {}


}