class D3D11FullscreenMode {


    /**
     * Exclusive mode.
     */
    get ExclusiveMode() {}

    /**
     * Exclusive mode.
     */
    set ExclusiveMode(value) {}

    /**
     * Fullscreen window.
     */
    get FullscreenWindow() {}

    /**
     * Fullscreen window.
     */
    set FullscreenWindow(value) {}


}