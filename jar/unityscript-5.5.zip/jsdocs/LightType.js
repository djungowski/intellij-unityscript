class LightType {


    /**
     * The light is a spot light.
     */
    get Spot() {}

    /**
     * The light is a spot light.
     */
    set Spot(value) {}

    /**
     * The light is a directional light.
     */
    get Directional() {}

    /**
     * The light is a directional light.
     */
    set Directional(value) {}

    /**
     * The light is a point light.
     */
    get Point() {}

    /**
     * The light is a point light.
     */
    set Point(value) {}

    /**
     * The light is an area light. It affects only lightmaps and lightprobes.
     */
    get Area() {}

    /**
     * The light is an area light. It affects only lightmaps and lightprobes.
     */
    set Area(value) {}


}