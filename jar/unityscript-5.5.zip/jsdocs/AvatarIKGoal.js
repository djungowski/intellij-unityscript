class AvatarIKGoal {


    /**
     * The left foot.
     */
    get LeftFoot() {}

    /**
     * The left foot.
     */
    set LeftFoot(value) {}

    /**
     * The right foot.
     */
    get RightFoot() {}

    /**
     * The right foot.
     */
    set RightFoot(value) {}

    /**
     * The left hand.
     */
    get LeftHand() {}

    /**
     * The left hand.
     */
    set LeftHand(value) {}

    /**
     * The right hand.
     */
    get RightHand() {}

    /**
     * The right hand.
     */
    set RightHand(value) {}


}