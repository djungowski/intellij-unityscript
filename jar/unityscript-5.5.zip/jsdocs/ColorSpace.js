class ColorSpace {


    /**
     * Uninitialized color space.
     */
    get Uninitialized() {}

    /**
     * Uninitialized color space.
     */
    set Uninitialized(value) {}

    /**
     * Gamma color space.
     */
    get Gamma() {}

    /**
     * Gamma color space.
     */
    set Gamma(value) {}

    /**
     * Linear color space.
     */
    get Linear() {}

    /**
     * Linear color space.
     */
    set Linear(value) {}


}