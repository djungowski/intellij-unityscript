class Handheld {

    /**
     * Gets the current activity indicator style.
     */
    static GetActivityIndicatorStyle() {}

    /**
     * Plays a full-screen movie.
     */
    static PlayFullScreenMovie() {}

    /**
     * Sets the desired activity indicator style.
     */
    static SetActivityIndicatorStyle() {}

    /**
     * Starts os activity indicator.
     */
    static StartActivityIndicator() {}

    /**
     * Stops os activity indicator.
     */
    static StopActivityIndicator() {}

    /**
     * Triggers device vibration.
     */
    static Vibrate() {}



}