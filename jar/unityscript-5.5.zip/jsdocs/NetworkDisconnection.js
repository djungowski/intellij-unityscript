class NetworkDisconnection {


    /**
     * The connection to the system has been lost, no reliable packets could be delivered.
     */
    get LostConnection() {}

    /**
     * The connection to the system has been lost, no reliable packets could be delivered.
     */
    set LostConnection(value) {}

    /**
     * The connection to the system has been closed.
     */
    get Disconnected() {}

    /**
     * The connection to the system has been closed.
     */
    set Disconnected(value) {}


}