class BoneWeight {


    /**
     * Index of first bone.
     */
    get boneIndex0() {}

    /**
     * Index of first bone.
     */
    set boneIndex0(value) {}

    /**
     * Index of second bone.
     */
    get boneIndex1() {}

    /**
     * Index of second bone.
     */
    set boneIndex1(value) {}

    /**
     * Index of third bone.
     */
    get boneIndex2() {}

    /**
     * Index of third bone.
     */
    set boneIndex2(value) {}

    /**
     * Index of fourth bone.
     */
    get boneIndex3() {}

    /**
     * Index of fourth bone.
     */
    set boneIndex3(value) {}

    /**
     * Skinning weight for first bone.
     */
    get weight0() {}

    /**
     * Skinning weight for first bone.
     */
    set weight0(value) {}

    /**
     * Skinning weight for second bone.
     */
    get weight1() {}

    /**
     * Skinning weight for second bone.
     */
    set weight1(value) {}

    /**
     * Skinning weight for third bone.
     */
    get weight2() {}

    /**
     * Skinning weight for third bone.
     */
    set weight2(value) {}

    /**
     * Skinning weight for fourth bone.
     */
    get weight3() {}

    /**
     * Skinning weight for fourth bone.
     */
    set weight3(value) {}


}