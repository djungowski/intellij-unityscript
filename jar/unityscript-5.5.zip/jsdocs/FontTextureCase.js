class FontTextureCase {


    /**
     * Render characters into font texture at runtime as needed.
     */
    get Dynamic() {}

    /**
     * Render characters into font texture at runtime as needed.
     */
    set Dynamic(value) {}

    /**
     * Import a set of Unicode characters common for latin scripts.
     */
    get Unicode() {}

    /**
     * Import a set of Unicode characters common for latin scripts.
     */
    set Unicode(value) {}

    /**
     * Import basic ASCII character set.
     */
    get ASCII() {}

    /**
     * Import basic ASCII character set.
     */
    set ASCII(value) {}

    /**
     * Only import upper case ASCII character set.
     */
    get ASCIIUpperCase() {}

    /**
     * Only import upper case ASCII character set.
     */
    set ASCIIUpperCase(value) {}

    /**
     * Only import lower case ASCII character set.
     */
    get ASCIILowerCase() {}

    /**
     * Only import lower case ASCII character set.
     */
    set ASCIILowerCase(value) {}

    /**
     * Custom set of characters.
     */
    get CustomSet() {}

    /**
     * Custom set of characters.
     */
    set CustomSet(value) {}


}