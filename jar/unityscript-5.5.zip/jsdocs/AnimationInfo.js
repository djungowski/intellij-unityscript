class AnimationInfo {



}