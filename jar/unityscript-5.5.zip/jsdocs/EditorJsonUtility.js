class EditorJsonUtility {

    /**
     * Overwrite data in an object by reading from its JSON representation.
     */
    static FromJsonOverwrite() {}

    /**
     * Generate a JSON representation of an object.
     */
    static ToJson() {}



}