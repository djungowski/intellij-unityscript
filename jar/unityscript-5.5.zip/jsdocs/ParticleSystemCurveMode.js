class ParticleSystemCurveMode {


    /**
     * Use a single constant for the MinMaxCurve.
     */
    get Constant() {}

    /**
     * Use a single constant for the MinMaxCurve.
     */
    set Constant(value) {}

    /**
     * Use a single curve for the MinMaxCurve.
     */
    get Curve() {}

    /**
     * Use a single curve for the MinMaxCurve.
     */
    set Curve(value) {}

    /**
     * Use a random value between 2 curves for the MinMaxCurve.
     */
    get TwoCurves() {}

    /**
     * Use a random value between 2 curves for the MinMaxCurve.
     */
    set TwoCurves(value) {}

    /**
     * Use a random value between 2 constants for the MinMaxCurve.
     */
    get TwoConstants() {}

    /**
     * Use a random value between 2 constants for the MinMaxCurve.
     */
    set TwoConstants(value) {}


}