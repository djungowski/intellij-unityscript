class AnimatorUtility {

    /**
     * This function will recreate all transform hierarchy under GameObject.
     */
    static DeoptimizeTransformHierarchy() {}

    /**
     * This function will remove all transform hierarchy under GameObject, the animator will write directly transform matrices into the skin mesh matrices saving alot of CPU cycles.
     */
    static OptimizeTransformHierarchy() {}



}