class LightShadows {


    /**
     * Do not cast shadows (default).
     */
    get None() {}

    /**
     * Do not cast shadows (default).
     */
    set None(value) {}

    /**
     * Cast &quot;hard&quot; shadows (with no shadow filtering).
     */
    get Hard() {}

    /**
     * Cast &quot;hard&quot; shadows (with no shadow filtering).
     */
    set Hard(value) {}

    /**
     * Cast &quot;soft&quot; shadows (with 4x PCF filtering).
     */
    get Soft() {}

    /**
     * Cast &quot;soft&quot; shadows (with 4x PCF filtering).
     */
    set Soft(value) {}


}