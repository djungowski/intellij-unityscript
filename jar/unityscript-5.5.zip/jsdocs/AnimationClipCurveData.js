class AnimationClipCurveData {


    /**
     * The actual animation curve.
     */
    get curve() {}

    /**
     * The actual animation curve.
     */
    set curve(value) {}

    /**
     * The path of the game object / bone being animated.
     */
    get path() {}

    /**
     * The path of the game object / bone being animated.
     */
    set path(value) {}

    /**
     * The name of the property being animated.
     */
    get propertyName() {}

    /**
     * The name of the property being animated.
     */
    set propertyName(value) {}

    /**
     * The type of the component / material being animated.
     */
    get type() {}

    /**
     * The type of the component / material being animated.
     */
    set type(value) {}


}