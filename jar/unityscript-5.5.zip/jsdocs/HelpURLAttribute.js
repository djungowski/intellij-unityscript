class HelpURLAttribute {


    /**
     * The documentation URL specified for this class.
     */
    get URL() {}

    /**
     * The documentation URL specified for this class.
     */
    set URL(value) {}


}