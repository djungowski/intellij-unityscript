class Cursor {
    /**
     * Determines whether the hardware pointer is locked to the center of the view, constrained to the window, or not constrained at all.
     */
    static get lockState() {}

    /**
     * Determines whether the hardware pointer is locked to the center of the view, constrained to the window, or not constrained at all.
     */
    static set lockState(value) {}

    /**
     * Determines whether the hardware pointer is visible or not.
     */
    static get visible() {}

    /**
     * Determines whether the hardware pointer is visible or not.
     */
    static set visible(value) {}


    /**
     * Sets the mouse cursor to the given texture.
     */
    static SetCursor() {}



}