class AnimationClipPair {


    /**
     * The original clip from the controller.
     */
    get originalClip() {}

    /**
     * The original clip from the controller.
     */
    set originalClip(value) {}

    /**
     * The override animation clip.
     */
    get overrideClip() {}

    /**
     * The override animation clip.
     */
    set overrideClip(value) {}


}