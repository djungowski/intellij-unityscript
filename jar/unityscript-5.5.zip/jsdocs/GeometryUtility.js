class GeometryUtility {

    /**
     * Calculates a bounding box given an array of positions and a transformation matrix.
     */
    static CalculateBounds() {}

    /**
     * Calculates frustum planes.
     */
    static CalculateFrustumPlanes() {}

    /**
     * Returns true if bounds are inside the plane array.
     */
    static TestPlanesAABB() {}



}