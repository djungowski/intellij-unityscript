class ArrayUtility {

    /**
     * Appends item to the end of array.
     */
    static Add() {}

    /**
     * Appends items to the end of array.
     */
    static AddRange() {}

    /**
     * Compares two arrays.
     */
    static ArrayEquals() {}

    /**
     * Clears the array.
     */
    static Clear() {}

    /**
     * Determines if the array contains the item.
     */
    static Contains() {}

    /**
     * Find the index of the first element that satisfies the predicate.
     */
    static FindIndex() {}

    /**
     * Index of first element with value value.
     */
    static IndexOf() {}

    /**
     * Inserts item item at position index.
     */
    static Insert() {}

    /**
     * Index of the last element with value value.
     */
    static LastIndexOf() {}

    /**
     * Removes item from array.
     */
    static Remove() {}

    /**
     * Remove element at position index.
     */
    static RemoveAt() {}



}