class DrivenRectTransformTracker {



    /**
     * Add a RectTransform to be driven.
     */
    Add() {}

    /**
     * Clear the list of RectTransforms being driven.
     */
    Clear() {}

}