class CrashReport {
    /**
     * Returns last crash report, or null if no reports are available.
     */
    static get lastReport() {}

    /**
     * Returns last crash report, or null if no reports are available.
     */
    static set lastReport(value) {}

    /**
     * Returns all currently available reports in a new array.
     */
    static get reports() {}

    /**
     * Returns all currently available reports in a new array.
     */
    static set reports(value) {}


    /**
     * Remove all reports from available reports list.
     */
    static RemoveAll() {}


    /**
     * Crash report data as formatted text.
     */
    get text() {}

    /**
     * Crash report data as formatted text.
     */
    set text(value) {}

    /**
     * Time, when the crash occured.
     */
    get time() {}

    /**
     * Time, when the crash occured.
     */
    set time(value) {}


    /**
     * Remove report from available reports list.
     */
    Remove() {}

}