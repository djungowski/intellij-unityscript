class ParticleSystemAnimationType {


    /**
     * Animate over the whole texture sheet from left to right, top to bottom.
     */
    get WholeSheet() {}

    /**
     * Animate over the whole texture sheet from left to right, top to bottom.
     */
    set WholeSheet(value) {}

    /**
     * Animate a single row in the sheet from left to right.
     */
    get SingleRow() {}

    /**
     * Animate a single row in the sheet from left to right.
     */
    set SingleRow(value) {}


}