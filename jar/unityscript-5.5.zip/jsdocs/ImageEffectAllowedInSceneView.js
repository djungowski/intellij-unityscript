class ImageEffectAllowedInSceneView {



}