class BitStream {


    /**
     * Is the BitStream currently being read? (Read Only)
     */
    get isReading() {}

    /**
     * Is the BitStream currently being read? (Read Only)
     */
    set isReading(value) {}

    /**
     * Is the BitStream currently being written? (Read Only)
     */
    get isWriting() {}

    /**
     * Is the BitStream currently being written? (Read Only)
     */
    set isWriting(value) {}


    /**
     * Serializes different types of variables.
     */
    Serialize() {}

}