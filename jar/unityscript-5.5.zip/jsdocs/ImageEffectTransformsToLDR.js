class ImageEffectTransformsToLDR {



}