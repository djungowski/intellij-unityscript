class iOSDeviceRequirement {


    /**
     * The values of the device requirement description.
     */
    get values() {}

    /**
     * The values of the device requirement description.
     */
    set values(value) {}


}