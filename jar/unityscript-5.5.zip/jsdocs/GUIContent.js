class GUIContent {
    /**
     * Shorthand for empty content.
     */
    static get none() {}

    /**
     * Shorthand for empty content.
     */
    static set none(value) {}



    /**
     * The icon image contained.
     */
    get image() {}

    /**
     * The icon image contained.
     */
    set image(value) {}

    /**
     * The text contained.
     */
    get text() {}

    /**
     * The text contained.
     */
    set text(value) {}

    /**
     * The tooltip of this element.
     */
    get tooltip() {}

    /**
     * The tooltip of this element.
     */
    set tooltip(value) {}


}