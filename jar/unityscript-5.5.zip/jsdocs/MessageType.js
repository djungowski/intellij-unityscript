class MessageType {


    /**
     * Neutral message.
     */
    get None() {}

    /**
     * Neutral message.
     */
    set None(value) {}

    /**
     * Info message.
     */
    get Info() {}

    /**
     * Info message.
     */
    set Info(value) {}

    /**
     * Warning message.
     */
    get Warning() {}

    /**
     * Warning message.
     */
    set Warning(value) {}

    /**
     * Error message.
     */
    get Error() {}

    /**
     * Error message.
     */
    set Error(value) {}


}