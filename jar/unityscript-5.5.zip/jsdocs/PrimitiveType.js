class PrimitiveType {


    /**
     * A sphere primitive.
     */
    get Sphere() {}

    /**
     * A sphere primitive.
     */
    set Sphere(value) {}

    /**
     * A capsule primitive.
     */
    get Capsule() {}

    /**
     * A capsule primitive.
     */
    set Capsule(value) {}

    /**
     * A cylinder primitive.
     */
    get Cylinder() {}

    /**
     * A cylinder primitive.
     */
    set Cylinder(value) {}

    /**
     * A cube primitive.
     */
    get Cube() {}

    /**
     * A cube primitive.
     */
    set Cube(value) {}

    /**
     * A plane primitive.
     */
    get Plane() {}

    /**
     * A plane primitive.
     */
    set Plane(value) {}

    /**
     * A Quad primitive.
     */
    get Quad() {}

    /**
     * A Quad primitive.
     */
    set Quad(value) {}


}