class Gradient {


    /**
     * All alpha keys defined in the gradient.
     */
    get alphaKeys() {}

    /**
     * All alpha keys defined in the gradient.
     */
    set alphaKeys(value) {}

    /**
     * All color keys defined in the gradient.
     */
    get colorKeys() {}

    /**
     * All color keys defined in the gradient.
     */
    set colorKeys(value) {}

    /**
     * Control how the gradient is evaluated.
     */
    get mode() {}

    /**
     * Control how the gradient is evaluated.
     */
    set mode(value) {}


    /**
     * Calculate color at a given time.
     */
    Evaluate() {}

    /**
     * Setup Gradient with an array of color keys and alpha keys.
     */
    SetKeys() {}

}