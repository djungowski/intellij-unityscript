class AssetBundleBuild {


    /**
     * AssetBundle name.
     */
    get assetBundleName() {}

    /**
     * AssetBundle name.
     */
    set assetBundleName(value) {}

    /**
     * AssetBundle variant.
     */
    get assetBundleVariant() {}

    /**
     * AssetBundle variant.
     */
    set assetBundleVariant(value) {}

    /**
     * Asset names which belong to the given AssetBundle.
     */
    get assetNames() {}

    /**
     * Asset names which belong to the given AssetBundle.
     */
    set assetNames(value) {}


}