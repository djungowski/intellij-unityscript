class CustomYieldInstruction {


    /**
     * Indicates if coroutine should be kept suspended.
     */
    get keepWaiting() {}

    /**
     * Indicates if coroutine should be kept suspended.
     */
    set keepWaiting(value) {}


}