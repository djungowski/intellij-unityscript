class CombineInstance {


    /**
     * 
          Mesh to combine.
     */
    get mesh() {}

    /**
     * 
          Mesh to combine.
     */
    set mesh(value) {}

    /**
     * Submesh index of the mesh.
     */
    get subMeshIndex() {}

    /**
     * Submesh index of the mesh.
     */
    set subMeshIndex(value) {}

    /**
     * Matrix to transform the mesh with before combining.
     */
    get transform() {}

    /**
     * Matrix to transform the mesh with before combining.
     */
    set transform(value) {}


}