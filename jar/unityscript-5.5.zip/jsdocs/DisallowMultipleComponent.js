class DisallowMultipleComponent {



}