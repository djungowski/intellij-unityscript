class iOSTargetDevice {


    /**
     * iPhone/iPod Only.
     */
    get iPhoneOnly() {}

    /**
     * iPhone/iPod Only.
     */
    set iPhoneOnly(value) {}

    /**
     * iPad Only.
     */
    get iPadOnly() {}

    /**
     * iPad Only.
     */
    set iPadOnly(value) {}

    /**
     * Universal : iPhone/iPod + iPad.
     */
    get iPhoneAndiPad() {}

    /**
     * Universal : iPhone/iPod + iPad.
     */
    set iPhoneAndiPad(value) {}


}