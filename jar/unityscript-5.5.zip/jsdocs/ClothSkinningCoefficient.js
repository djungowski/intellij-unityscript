class ClothSkinningCoefficient {


    /**
     * Definition of a sphere a vertex is not allowed to enter. This allows collision against the animated cloth.
     */
    get collisionSphereDistance() {}

    /**
     * Definition of a sphere a vertex is not allowed to enter. This allows collision against the animated cloth.
     */
    set collisionSphereDistance(value) {}

    /**
     * Distance a vertex is allowed to travel from the skinned mesh vertex position.
     */
    get maxDistance() {}

    /**
     * Distance a vertex is allowed to travel from the skinned mesh vertex position.
     */
    set maxDistance(value) {}


}