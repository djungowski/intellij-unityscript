class iOSShowActivityIndicatorOnLoading {


    /**
     * White Large.
     */
    get WhiteLarge() {}

    /**
     * White Large.
     */
    set WhiteLarge(value) {}

    /**
     * White.
     */
    get White() {}

    /**
     * White.
     */
    set White(value) {}

    /**
     * Gray.
     */
    get Gray() {}

    /**
     * Gray.
     */
    set Gray(value) {}

    /**
     * Don&#039;t Show.
     */
    get DontShow() {}

    /**
     * Don&#039;t Show.
     */
    set DontShow(value) {}


}