class AvatarBuilder {

    /**
     * Create a new generic avatar.
     */
    static BuildGenericAvatar() {}

    /**
     * Create a humanoid avatar.
     */
    static BuildHumanAvatar() {}



}