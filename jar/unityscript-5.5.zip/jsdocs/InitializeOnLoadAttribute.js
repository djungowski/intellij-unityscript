class InitializeOnLoadAttribute {



}