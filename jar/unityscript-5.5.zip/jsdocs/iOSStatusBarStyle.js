class iOSStatusBarStyle {


    /**
     * Default.
     */
    get Default() {}

    /**
     * Default.
     */
    set Default(value) {}

    /**
     * Black translucent.
     */
    get BlackTranslucent() {}

    /**
     * Black translucent.
     */
    set BlackTranslucent(value) {}

    /**
     * Black opaque.
     */
    get BlackOpaque() {}

    /**
     * Black opaque.
     */
    set BlackOpaque(value) {}


}