class EffectorSelection2D {


    /**
     * The source/target is defined by the Rigidbody2D.
     */
    get Rigidbody() {}

    /**
     * The source/target is defined by the Rigidbody2D.
     */
    set Rigidbody(value) {}

    /**
     * The source/target is defined by the Collider2D.
     */
    get Collider() {}

    /**
     * The source/target is defined by the Collider2D.
     */
    set Collider(value) {}


}