class GradientColorKey {


    /**
     * Color of key.
     */
    get color() {}

    /**
     * Color of key.
     */
    set color(value) {}

    /**
     * Time of the key (0 - 1).
     */
    get time() {}

    /**
     * Time of the key (0 - 1).
     */
    set time(value) {}


}