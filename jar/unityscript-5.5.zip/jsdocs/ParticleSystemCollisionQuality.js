class ParticleSystemCollisionQuality {


    /**
     * The most accurate world collisions.
     */
    get High() {}

    /**
     * The most accurate world collisions.
     */
    set High(value) {}

    /**
     * Approximate world collisions.
     */
    get Medium() {}

    /**
     * Approximate world collisions.
     */
    set Medium(value) {}

    /**
     * Fastest and most approximate world collisions.
     */
    get Low() {}

    /**
     * Fastest and most approximate world collisions.
     */
    set Low(value) {}


}