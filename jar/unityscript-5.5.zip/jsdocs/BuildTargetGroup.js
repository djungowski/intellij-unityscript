class BuildTargetGroup {


    /**
     * Unknown target.
     */
    get Unknown() {}

    /**
     * Unknown target.
     */
    set Unknown(value) {}

    /**
     * Mac/PC standalone target.
     */
    get Standalone() {}

    /**
     * Mac/PC standalone target.
     */
    set Standalone(value) {}

    /**
     * Apple iOS target.
     */
    get iOS() {}

    /**
     * Apple iOS target.
     */
    set iOS(value) {}

    /**
     * Android target.
     */
    get Android() {}

    /**
     * Android target.
     */
    set Android(value) {}

    /**
     * WebGL.
     */
    get WebGL() {}

    /**
     * WebGL.
     */
    set WebGL(value) {}

    /**
     * Windows Store Apps target.
     */
    get WSA() {}

    /**
     * Windows Store Apps target.
     */
    set WSA(value) {}

    /**
     * Samsung Tizen target.
     */
    get Tizen() {}

    /**
     * Samsung Tizen target.
     */
    set Tizen(value) {}

    /**
     * Sony PS Vita target.
     */
    get PSP2() {}

    /**
     * Sony PS Vita target.
     */
    set PSP2(value) {}

    /**
     * Sony Playstation 4 target.
     */
    get PS4() {}

    /**
     * Sony Playstation 4 target.
     */
    set PS4(value) {}

    /**
     * Microsoft Xbox One target.
     */
    get XboxOne() {}

    /**
     * Microsoft Xbox One target.
     */
    set XboxOne(value) {}

    /**
     * Samsung Smart TV target.
     */
    get SamsungTV() {}

    /**
     * Samsung Smart TV target.
     */
    set SamsungTV(value) {}

    /**
     * Nintendo 3DS target.
     */
    get N3DS() {}

    /**
     * Nintendo 3DS target.
     */
    set N3DS(value) {}

    /**
     * Nintendo Wii U target.
     */
    get WiiU() {}

    /**
     * Nintendo Wii U target.
     */
    set WiiU(value) {}

    /**
     * Apple&#039;s tvOS target.
     */
    get tvOS() {}

    /**
     * Apple&#039;s tvOS target.
     */
    set tvOS(value) {}


}