class CapsuleDirection2D {


    /**
     * The capsule sides extend vertically.
     */
    get Vertical() {}

    /**
     * The capsule sides extend vertically.
     */
    set Vertical(value) {}

    /**
     * The capsule sides extend horizontally.
     */
    get Horizontal() {}

    /**
     * The capsule sides extend horizontally.
     */
    set Horizontal(value) {}


}