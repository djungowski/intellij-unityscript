class ILogHandler {



    /**
     * A variant of ILogHandler.LogFormat that logs an exception message.
     */
    LogException() {}

    /**
     * Logs a formatted message.
     */
    LogFormat() {}

}