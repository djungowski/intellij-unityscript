class LODUtility {

    /**
     * Recalculate the bounding region for the given LODGroup.
     */
    static CalculateLODGroupBoundingBox() {}



}