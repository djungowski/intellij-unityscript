class CubemapFace {


    /**
     * Cubemap face is unknown or unspecified.
     */
    get Unknown() {}

    /**
     * Cubemap face is unknown or unspecified.
     */
    set Unknown(value) {}

    /**
     * Right facing side (+x).
     */
    get PositiveX() {}

    /**
     * Right facing side (+x).
     */
    set PositiveX(value) {}

    /**
     * Left facing side (-x).
     */
    get NegativeX() {}

    /**
     * Left facing side (-x).
     */
    set NegativeX(value) {}

    /**
     * Upwards facing side (+y).
     */
    get PositiveY() {}

    /**
     * Upwards facing side (+y).
     */
    set PositiveY(value) {}

    /**
     * Downward facing side (-y).
     */
    get NegativeY() {}

    /**
     * Downward facing side (-y).
     */
    set NegativeY(value) {}

    /**
     * Forward facing side (+z).
     */
    get PositiveZ() {}

    /**
     * Forward facing side (+z).
     */
    set PositiveZ(value) {}

    /**
     * Backward facing side (-z).
     */
    get NegativeZ() {}

    /**
     * Backward facing side (-z).
     */
    set NegativeZ(value) {}


}