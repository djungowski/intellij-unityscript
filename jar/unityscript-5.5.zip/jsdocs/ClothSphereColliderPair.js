class ClothSphereColliderPair {


    /**
     * The first SphereCollider of a ClothSphereColliderPair.
     */
    get first() {}

    /**
     * The first SphereCollider of a ClothSphereColliderPair.
     */
    set first(value) {}

    /**
     * The second SphereCollider of a ClothSphereColliderPair.
     */
    get second() {}

    /**
     * The second SphereCollider of a ClothSphereColliderPair.
     */
    set second(value) {}


}