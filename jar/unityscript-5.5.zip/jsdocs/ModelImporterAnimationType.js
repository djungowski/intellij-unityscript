class ModelImporterAnimationType {


    /**
     * Generate no animation data.
     */
    get None() {}

    /**
     * Generate no animation data.
     */
    set None(value) {}

    /**
     * Generate a legacy animation type.
     */
    get Legacy() {}

    /**
     * Generate a legacy animation type.
     */
    set Legacy(value) {}

    /**
     * Generate a generic animator.
     */
    get Generic() {}

    /**
     * Generate a generic animator.
     */
    set Generic(value) {}

    /**
     * Generate a human animator.
     */
    get Human() {}

    /**
     * Generate a human animator.
     */
    set Human(value) {}


}