class AddComponentMenu {


    /**
     * The order of the component in the component menu (lower is higher to the top).
     */
    get componentOrder() {}

    /**
     * The order of the component in the component menu (lower is higher to the top).
     */
    set componentOrder(value) {}


}