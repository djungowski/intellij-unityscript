class BuildPipeline {
    /**
     * Is a player currently being built?
     */
    static get isBuildingPlayer() {}

    /**
     * Is a player currently being built?
     */
    static set isBuildingPlayer(value) {}


    /**
     * Build all AssetBundles specified in the editor.
     */
    static BuildAssetBundles() {}

    /**
     * Builds a player.
     */
    static BuildPlayer() {}

    /**
     * Extract the crc checksum for the given AssetBundle.
     */
    static GetCRCForAssetBundle() {}

    /**
     * Extract the hash for the given AssetBundle.
     */
    static GetHashForAssetBundle() {}



}