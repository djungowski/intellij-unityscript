class PivotRotation {


    /**
     * The tool handle is oriented from the active object.
     */
    get Local() {}

    /**
     * The tool handle is oriented from the active object.
     */
    set Local(value) {}

    /**
     * The tool handle is aligned along the global axes.
     */
    get Global() {}

    /**
     * The tool handle is aligned along the global axes.
     */
    set Global(value) {}


}