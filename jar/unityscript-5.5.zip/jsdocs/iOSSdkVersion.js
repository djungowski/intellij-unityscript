class iOSSdkVersion {


    /**
     * Device SDK.
     */
    get DeviceSDK() {}

    /**
     * Device SDK.
     */
    set DeviceSDK(value) {}

    /**
     * Simulator SDK.
     */
    get SimulatorSDK() {}

    /**
     * Simulator SDK.
     */
    set SimulatorSDK(value) {}


}