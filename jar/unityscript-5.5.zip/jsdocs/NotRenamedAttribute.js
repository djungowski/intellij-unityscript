class NotRenamedAttribute {



}