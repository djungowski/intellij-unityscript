class MatchTargetWeightMask {


    /**
     * Position XYZ weight.
     */
    get positionXYZWeight() {}

    /**
     * Position XYZ weight.
     */
    set positionXYZWeight(value) {}

    /**
     * Rotation weight.
     */
    get rotationWeight() {}

    /**
     * Rotation weight.
     */
    set rotationWeight(value) {}


}