class CursorMode {


    /**
     * Use hardware cursors on supported platforms.
     */
    get Auto() {}

    /**
     * Use hardware cursors on supported platforms.
     */
    set Auto(value) {}

    /**
     * Force the use of software cursors.
     */
    get ForceSoftware() {}

    /**
     * Force the use of software cursors.
     */
    set ForceSoftware(value) {}


}