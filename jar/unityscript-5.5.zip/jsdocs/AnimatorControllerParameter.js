class AnimatorControllerParameter {


    /**
     * The default bool value for the parameter.
     */
    get defaultBool() {}

    /**
     * The default bool value for the parameter.
     */
    set defaultBool(value) {}

    /**
     * The default bool value for the parameter.
     */
    get defaultFloat() {}

    /**
     * The default bool value for the parameter.
     */
    set defaultFloat(value) {}

    /**
     * The default bool value for the parameter.
     */
    get defaultInt() {}

    /**
     * The default bool value for the parameter.
     */
    set defaultInt(value) {}

    /**
     * The name of the parameter.
     */
    get name() {}

    /**
     * The name of the parameter.
     */
    set name(value) {}

    /**
     * Returns the hash of the parameter based on its name.
     */
    get nameHash() {}

    /**
     * Returns the hash of the parameter based on its name.
     */
    set nameHash(value) {}

    /**
     * The type of the parameter.
     */
    get type() {}

    /**
     * The type of the parameter.
     */
    set type(value) {}


}