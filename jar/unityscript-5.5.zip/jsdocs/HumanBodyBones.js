class HumanBodyBones {


    /**
     * This is the Hips bone.
     */
    get Hips() {}

    /**
     * This is the Hips bone.
     */
    set Hips(value) {}

    /**
     * This is the Left Upper Leg bone.
     */
    get LeftUpperLeg() {}

    /**
     * This is the Left Upper Leg bone.
     */
    set LeftUpperLeg(value) {}

    /**
     * This is the Right Upper Leg bone.
     */
    get RightUpperLeg() {}

    /**
     * This is the Right Upper Leg bone.
     */
    set RightUpperLeg(value) {}

    /**
     * This is the Left Knee bone.
     */
    get LeftLowerLeg() {}

    /**
     * This is the Left Knee bone.
     */
    set LeftLowerLeg(value) {}

    /**
     * This is the Right Knee bone.
     */
    get RightLowerLeg() {}

    /**
     * This is the Right Knee bone.
     */
    set RightLowerLeg(value) {}

    /**
     * This is the Left Ankle bone.
     */
    get LeftFoot() {}

    /**
     * This is the Left Ankle bone.
     */
    set LeftFoot(value) {}

    /**
     * This is the Right Ankle bone.
     */
    get RightFoot() {}

    /**
     * This is the Right Ankle bone.
     */
    set RightFoot(value) {}

    /**
     * This is the first Spine bone.
     */
    get Spine() {}

    /**
     * This is the first Spine bone.
     */
    set Spine(value) {}

    /**
     * This is the Chest bone.
     */
    get Chest() {}

    /**
     * This is the Chest bone.
     */
    set Chest(value) {}

    /**
     * This is the Neck bone.
     */
    get Neck() {}

    /**
     * This is the Neck bone.
     */
    set Neck(value) {}

    /**
     * This is the Head bone.
     */
    get Head() {}

    /**
     * This is the Head bone.
     */
    set Head(value) {}

    /**
     * This is the Left Shoulder bone.
     */
    get LeftShoulder() {}

    /**
     * This is the Left Shoulder bone.
     */
    set LeftShoulder(value) {}

    /**
     * This is the Right Shoulder bone.
     */
    get RightShoulder() {}

    /**
     * This is the Right Shoulder bone.
     */
    set RightShoulder(value) {}

    /**
     * This is the Left Upper Arm bone.
     */
    get LeftUpperArm() {}

    /**
     * This is the Left Upper Arm bone.
     */
    set LeftUpperArm(value) {}

    /**
     * This is the Right Upper Arm bone.
     */
    get RightUpperArm() {}

    /**
     * This is the Right Upper Arm bone.
     */
    set RightUpperArm(value) {}

    /**
     * This is the Left Elbow bone.
     */
    get LeftLowerArm() {}

    /**
     * This is the Left Elbow bone.
     */
    set LeftLowerArm(value) {}

    /**
     * This is the Right Elbow bone.
     */
    get RightLowerArm() {}

    /**
     * This is the Right Elbow bone.
     */
    set RightLowerArm(value) {}

    /**
     * This is the Left Wrist bone.
     */
    get LeftHand() {}

    /**
     * This is the Left Wrist bone.
     */
    set LeftHand(value) {}

    /**
     * This is the Right Wrist bone.
     */
    get RightHand() {}

    /**
     * This is the Right Wrist bone.
     */
    set RightHand(value) {}

    /**
     * This is the Left Toes bone.
     */
    get LeftToes() {}

    /**
     * This is the Left Toes bone.
     */
    set LeftToes(value) {}

    /**
     * This is the Right Toes bone.
     */
    get RightToes() {}

    /**
     * This is the Right Toes bone.
     */
    set RightToes(value) {}

    /**
     * This is the Left Eye bone.
     */
    get LeftEye() {}

    /**
     * This is the Left Eye bone.
     */
    set LeftEye(value) {}

    /**
     * This is the Right Eye bone.
     */
    get RightEye() {}

    /**
     * This is the Right Eye bone.
     */
    set RightEye(value) {}

    /**
     * This is the Jaw bone.
     */
    get Jaw() {}

    /**
     * This is the Jaw bone.
     */
    set Jaw(value) {}

    /**
     * This is the left thumb 1st phalange.
     */
    get LeftThumbProximal() {}

    /**
     * This is the left thumb 1st phalange.
     */
    set LeftThumbProximal(value) {}

    /**
     * This is the left thumb 2nd phalange.
     */
    get LeftThumbIntermediate() {}

    /**
     * This is the left thumb 2nd phalange.
     */
    set LeftThumbIntermediate(value) {}

    /**
     * This is the left thumb 3rd phalange.
     */
    get LeftThumbDistal() {}

    /**
     * This is the left thumb 3rd phalange.
     */
    set LeftThumbDistal(value) {}

    /**
     * This is the left index 1st phalange.
     */
    get LeftIndexProximal() {}

    /**
     * This is the left index 1st phalange.
     */
    set LeftIndexProximal(value) {}

    /**
     * This is the left index 2nd phalange.
     */
    get LeftIndexIntermediate() {}

    /**
     * This is the left index 2nd phalange.
     */
    set LeftIndexIntermediate(value) {}

    /**
     * This is the left index 3rd phalange.
     */
    get LeftIndexDistal() {}

    /**
     * This is the left index 3rd phalange.
     */
    set LeftIndexDistal(value) {}

    /**
     * This is the left middle 1st phalange.
     */
    get LeftMiddleProximal() {}

    /**
     * This is the left middle 1st phalange.
     */
    set LeftMiddleProximal(value) {}

    /**
     * This is the left middle 2nd phalange.
     */
    get LeftMiddleIntermediate() {}

    /**
     * This is the left middle 2nd phalange.
     */
    set LeftMiddleIntermediate(value) {}

    /**
     * This is the left middle 3rd phalange.
     */
    get LeftMiddleDistal() {}

    /**
     * This is the left middle 3rd phalange.
     */
    set LeftMiddleDistal(value) {}

    /**
     * This is the left ring 1st phalange.
     */
    get LeftRingProximal() {}

    /**
     * This is the left ring 1st phalange.
     */
    set LeftRingProximal(value) {}

    /**
     * This is the left ring 2nd phalange.
     */
    get LeftRingIntermediate() {}

    /**
     * This is the left ring 2nd phalange.
     */
    set LeftRingIntermediate(value) {}

    /**
     * This is the left ring 3rd phalange.
     */
    get LeftRingDistal() {}

    /**
     * This is the left ring 3rd phalange.
     */
    set LeftRingDistal(value) {}

    /**
     * This is the left little 1st phalange.
     */
    get LeftLittleProximal() {}

    /**
     * This is the left little 1st phalange.
     */
    set LeftLittleProximal(value) {}

    /**
     * This is the left little 2nd phalange.
     */
    get LeftLittleIntermediate() {}

    /**
     * This is the left little 2nd phalange.
     */
    set LeftLittleIntermediate(value) {}

    /**
     * This is the left little 3rd phalange.
     */
    get LeftLittleDistal() {}

    /**
     * This is the left little 3rd phalange.
     */
    set LeftLittleDistal(value) {}

    /**
     * This is the right thumb 1st phalange.
     */
    get RightThumbProximal() {}

    /**
     * This is the right thumb 1st phalange.
     */
    set RightThumbProximal(value) {}

    /**
     * This is the right thumb 2nd phalange.
     */
    get RightThumbIntermediate() {}

    /**
     * This is the right thumb 2nd phalange.
     */
    set RightThumbIntermediate(value) {}

    /**
     * This is the right thumb 3rd phalange.
     */
    get RightThumbDistal() {}

    /**
     * This is the right thumb 3rd phalange.
     */
    set RightThumbDistal(value) {}

    /**
     * This is the right index 1st phalange.
     */
    get RightIndexProximal() {}

    /**
     * This is the right index 1st phalange.
     */
    set RightIndexProximal(value) {}

    /**
     * This is the right index 2nd phalange.
     */
    get RightIndexIntermediate() {}

    /**
     * This is the right index 2nd phalange.
     */
    set RightIndexIntermediate(value) {}

    /**
     * This is the right index 3rd phalange.
     */
    get RightIndexDistal() {}

    /**
     * This is the right index 3rd phalange.
     */
    set RightIndexDistal(value) {}

    /**
     * This is the right middle 1st phalange.
     */
    get RightMiddleProximal() {}

    /**
     * This is the right middle 1st phalange.
     */
    set RightMiddleProximal(value) {}

    /**
     * This is the right middle 2nd phalange.
     */
    get RightMiddleIntermediate() {}

    /**
     * This is the right middle 2nd phalange.
     */
    set RightMiddleIntermediate(value) {}

    /**
     * This is the right middle 3rd phalange.
     */
    get RightMiddleDistal() {}

    /**
     * This is the right middle 3rd phalange.
     */
    set RightMiddleDistal(value) {}

    /**
     * This is the right ring 1st phalange.
     */
    get RightRingProximal() {}

    /**
     * This is the right ring 1st phalange.
     */
    set RightRingProximal(value) {}

    /**
     * This is the right ring 2nd phalange.
     */
    get RightRingIntermediate() {}

    /**
     * This is the right ring 2nd phalange.
     */
    set RightRingIntermediate(value) {}

    /**
     * This is the right ring 3rd phalange.
     */
    get RightRingDistal() {}

    /**
     * This is the right ring 3rd phalange.
     */
    set RightRingDistal(value) {}

    /**
     * This is the right little 1st phalange.
     */
    get RightLittleProximal() {}

    /**
     * This is the right little 1st phalange.
     */
    set RightLittleProximal(value) {}

    /**
     * This is the right little 2nd phalange.
     */
    get RightLittleIntermediate() {}

    /**
     * This is the right little 2nd phalange.
     */
    set RightLittleIntermediate(value) {}

    /**
     * This is the right little 3rd phalange.
     */
    get RightLittleDistal() {}

    /**
     * This is the right little 3rd phalange.
     */
    set RightLittleDistal(value) {}

    /**
     * This is the Last bone index delimiter.
     */
    get LastBone() {}

    /**
     * This is the Last bone index delimiter.
     */
    set LastBone(value) {}


}