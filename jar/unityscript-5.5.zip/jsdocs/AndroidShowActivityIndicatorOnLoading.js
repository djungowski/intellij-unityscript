class AndroidShowActivityIndicatorOnLoading {


    /**
     * Large.
     */
    get Large() {}

    /**
     * Large.
     */
    set Large(value) {}

    /**
     * Inversed Large.
     */
    get InversedLarge() {}

    /**
     * Inversed Large.
     */
    set InversedLarge(value) {}

    /**
     * Small.
     */
    get Small() {}

    /**
     * Small.
     */
    set Small(value) {}

    /**
     * Inversed Small.
     */
    get InversedSmall() {}

    /**
     * Inversed Small.
     */
    set InversedSmall(value) {}

    /**
     * Don&#039;t Show.
     */
    get DontShow() {}

    /**
     * Don&#039;t Show.
     */
    set DontShow(value) {}


}