class ParticleSystemCollisionMode {


    /**
     * Use 3D colliders to collide particles against.
     */
    get Collision3D() {}

    /**
     * Use 3D colliders to collide particles against.
     */
    set Collision3D(value) {}

    /**
     * Use 2D colliders to collide particles against.
     */
    get Collision2D() {}

    /**
     * Use 2D colliders to collide particles against.
     */
    set Collision2D(value) {}


}