class ParticleSystemTrailTextureMode {


    /**
     * Map the texture once along the entire length of the trail.
     */
    get Stretch() {}

    /**
     * Map the texture once along the entire length of the trail.
     */
    set Stretch(value) {}

    /**
     * Repeat the texture along the trail. To set the tiling rate, use Material.SetTextureScale.
     */
    get Tile() {}

    /**
     * Repeat the texture along the trail. To set the tiling rate, use Material.SetTextureScale.
     */
    set Tile(value) {}


}