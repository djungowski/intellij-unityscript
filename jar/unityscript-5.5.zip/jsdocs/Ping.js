class Ping {


    /**
     * The IP target of the ping.
     */
    get ip() {}

    /**
     * The IP target of the ping.
     */
    set ip(value) {}

    /**
     * Has the ping function completed?
     */
    get isDone() {}

    /**
     * Has the ping function completed?
     */
    set isDone(value) {}

    /**
     * This property contains the ping time result after isDone returns true.
     */
    get time() {}

    /**
     * This property contains the ping time result after isDone returns true.
     */
    set time(value) {}


}