class MeshUtility {

    /**
     * Returns the mesh compression setting for a Mesh.
     */
    static GetMeshCompression() {}

    /**
     * Optimizes the mesh for GPU access.
     */
    static Optimize() {}

    /**
     * Change the mesh compression setting for a mesh.
     */
    static SetMeshCompression() {}

    /**
     * Will insert per-triangle uv2 in mesh and handle vertex splitting etc.
     */
    static SetPerTriangleUV2() {}



}