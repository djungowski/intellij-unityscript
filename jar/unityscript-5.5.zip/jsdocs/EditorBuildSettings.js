class EditorBuildSettings {
    /**
     * The list of Scenes that should be included in the build.
This is the same list of Scenes that is shown in the Build Settings window. You can modify this list to set up which Scenes should be included in the build.
     */
    static get scenes() {}

    /**
     * The list of Scenes that should be included in the build.
This is the same list of Scenes that is shown in the Build Settings window. You can modify this list to set up which Scenes should be included in the build.
     */
    static set scenes(value) {}




}