class FocusType {


    /**
     * This control can receive keyboard focus.
     */
    get Keyboard() {}

    /**
     * This control can receive keyboard focus.
     */
    set Keyboard(value) {}

    /**
     * This control can not receive keyboard focus.
     */
    get Passive() {}

    /**
     * This control can not receive keyboard focus.
     */
    set Passive(value) {}


}