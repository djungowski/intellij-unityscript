class PlayerPrefsException {



}