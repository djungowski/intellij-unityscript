class AspectRatio {


    /**
     * Undefined aspect ratios.
     */
    get AspectOthers() {}

    /**
     * Undefined aspect ratios.
     */
    set AspectOthers(value) {}

    /**
     * 4:3 aspect ratio.
     */
    get Aspect4by3() {}

    /**
     * 4:3 aspect ratio.
     */
    set Aspect4by3(value) {}

    /**
     * 5:4 aspect ratio.
     */
    get Aspect5by4() {}

    /**
     * 5:4 aspect ratio.
     */
    set Aspect5by4(value) {}

    /**
     * 16:10 aspect ratio.
     */
    get Aspect16by10() {}

    /**
     * 16:10 aspect ratio.
     */
    set Aspect16by10(value) {}

    /**
     * 16:9 aspect ratio.
     */
    get Aspect16by9() {}

    /**
     * 16:9 aspect ratio.
     */
    set Aspect16by9(value) {}


}