class AndroidSplashScreenScale {


    /**
     * Center.
     */
    get Center() {}

    /**
     * Center.
     */
    set Center(value) {}

    /**
     * Scale to fit.
     */
    get ScaleToFit() {}

    /**
     * Scale to fit.
     */
    set ScaleToFit(value) {}

    /**
     * Scale to fill.
     */
    get ScaleToFill() {}

    /**
     * Scale to fill.
     */
    set ScaleToFill(value) {}


}