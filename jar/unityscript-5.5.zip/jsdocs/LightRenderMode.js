class LightRenderMode {


    /**
     * Automatically choose the render mode.
     */
    get Auto() {}

    /**
     * Automatically choose the render mode.
     */
    set Auto(value) {}

    /**
     * Force the Light to be a pixel light.
     */
    get ForcePixel() {}

    /**
     * Force the Light to be a pixel light.
     */
    set ForcePixel(value) {}

    /**
     * Force the Light to be a vertex light.
     */
    get ForceVertex() {}

    /**
     * Force the Light to be a vertex light.
     */
    set ForceVertex(value) {}


}