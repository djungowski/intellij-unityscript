class HumanPose {


    /**
     * The human body position for that pose.
     */
    get bodyPosition() {}

    /**
     * The human body position for that pose.
     */
    set bodyPosition(value) {}

    /**
     * The human body orientation for that pose.
     */
    get bodyRotation() {}

    /**
     * The human body orientation for that pose.
     */
    set bodyRotation(value) {}

    /**
     * The array of muscle values for that pose.
     */
    get muscles() {}

    /**
     * The array of muscle values for that pose.
     */
    set muscles(value) {}


}