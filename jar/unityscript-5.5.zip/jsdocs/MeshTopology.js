class MeshTopology {


    /**
     * Mesh is made from triangles.
     */
    get Triangles() {}

    /**
     * Mesh is made from triangles.
     */
    set Triangles(value) {}

    /**
     * Mesh is made from quads.
     */
    get Quads() {}

    /**
     * Mesh is made from quads.
     */
    set Quads(value) {}

    /**
     * Mesh is made from lines.
     */
    get Lines() {}

    /**
     * Mesh is made from lines.
     */
    set Lines(value) {}

    /**
     * Mesh is a line strip.
     */
    get LineStrip() {}

    /**
     * Mesh is a line strip.
     */
    set LineStrip(value) {}

    /**
     * Mesh is made from points.
     */
    get Points() {}

    /**
     * Mesh is made from points.
     */
    set Points(value) {}


}