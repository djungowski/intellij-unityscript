class EditorCurveBinding {


    /**
     * The transform path of the object that is animated.
     */
    get path() {}

    /**
     * The transform path of the object that is animated.
     */
    set path(value) {}

    /**
     * The property of the object that is animated.
     */
    get propertyName() {}

    /**
     * The property of the object that is animated.
     */
    set propertyName(value) {}


}