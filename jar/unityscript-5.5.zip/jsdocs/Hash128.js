class Hash128 {

    /**
     * Convert the input string to Hash128.
     */
    static Parse() {}


    /**
     * Get if the hash value is valid or not. (Read Only)
     */
    get isValid() {}

    /**
     * Get if the hash value is valid or not. (Read Only)
     */
    set isValid(value) {}


    /**
     * Convert Hash128 to string.
     */
    ToString() {}

}