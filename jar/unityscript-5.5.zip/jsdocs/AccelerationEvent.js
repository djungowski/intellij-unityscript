class AccelerationEvent {


    /**
     * Value of acceleration.
     */
    get acceleration() {}

    /**
     * Value of acceleration.
     */
    set acceleration(value) {}

    /**
     * Amount of time passed since last accelerometer measurement.
     */
    get deltaTime() {}

    /**
     * Amount of time passed since last accelerometer measurement.
     */
    set deltaTime(value) {}


}