class ParticleSystemEmissionType {



}