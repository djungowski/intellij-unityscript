class ParticleSystemNoiseQuality {


    /**
     * Low quality 1D noise.
     */
    get Low() {}

    /**
     * Low quality 1D noise.
     */
    set Low(value) {}

    /**
     * Medium quality 2D noise.
     */
    get Medium() {}

    /**
     * Medium quality 2D noise.
     */
    set Medium(value) {}

    /**
     * High quality 3D noise.
     */
    get High() {}

    /**
     * High quality 3D noise.
     */
    set High(value) {}


}