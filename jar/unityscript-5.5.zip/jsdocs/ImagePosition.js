class ImagePosition {


    /**
     * Image is to the left of the text.
     */
    get ImageLeft() {}

    /**
     * Image is to the left of the text.
     */
    set ImageLeft(value) {}

    /**
     * Image is above the text.
     */
    get ImageAbove() {}

    /**
     * Image is above the text.
     */
    set ImageAbove(value) {}

    /**
     * Only the image is displayed.
     */
    get ImageOnly() {}

    /**
     * Only the image is displayed.
     */
    set ImageOnly(value) {}

    /**
     * Only the text is displayed.
     */
    get TextOnly() {}

    /**
     * Only the text is displayed.
     */
    set TextOnly(value) {}


}