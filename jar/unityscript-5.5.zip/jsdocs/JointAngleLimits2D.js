class JointAngleLimits2D {


    /**
     * Upper angular limit of rotation.
     */
    get max() {}

    /**
     * Upper angular limit of rotation.
     */
    set max(value) {}

    /**
     * Lower angular limit of rotation.
     */
    get min() {}

    /**
     * Lower angular limit of rotation.
     */
    set min(value) {}


}