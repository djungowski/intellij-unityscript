class LightmapData {


    /**
     * Lightmap storing only the indirect incoming light.
     */
    get lightmapDir() {}

    /**
     * Lightmap storing only the indirect incoming light.
     */
    set lightmapDir(value) {}

    /**
     * Lightmap storing the full incoming light.
     */
    get lightmapLight() {}

    /**
     * Lightmap storing the full incoming light.
     */
    set lightmapLight(value) {}


}