class BlendWeights {


    /**
     * One bone affects each vertex.
     */
    get OneBone() {}

    /**
     * One bone affects each vertex.
     */
    set OneBone(value) {}

    /**
     * Two bones affect each vertex.
     */
    get TwoBones() {}

    /**
     * Two bones affect each vertex.
     */
    set TwoBones(value) {}

    /**
     * Four bones affect each vertex.
     */
    get FourBones() {}

    /**
     * Four bones affect each vertex.
     */
    set FourBones(value) {}


}