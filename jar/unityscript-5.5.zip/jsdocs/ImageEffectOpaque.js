class ImageEffectOpaque {



}