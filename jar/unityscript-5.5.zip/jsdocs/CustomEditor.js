class CustomEditor {


    /**
     * If true, match this editor only if all non-fallback editors do not match. Defaults to false.
     */
    get isFallback() {}

    /**
     * If true, match this editor only if all non-fallback editors do not match. Defaults to false.
     */
    set isFallback(value) {}


}