class JsonUtility {

    /**
     * Create an object from its JSON representation.
     */
    static FromJson() {}

    /**
     * Overwrite data in an object by reading from its JSON representation.
     */
    static FromJsonOverwrite() {}

    /**
     * Generate a JSON representation of the public fields of an object.
     */
    static ToJson() {}



}