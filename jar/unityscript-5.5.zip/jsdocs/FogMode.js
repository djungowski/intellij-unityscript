class FogMode {


    /**
     * Linear fog.
     */
    get Linear() {}

    /**
     * Linear fog.
     */
    set Linear(value) {}

    /**
     * Exponential fog.
     */
    get Exponential() {}

    /**
     * Exponential fog.
     */
    set Exponential(value) {}

    /**
     * Exponential squared fog (default).
     */
    get ExponentialSquared() {}

    /**
     * Exponential squared fog (default).
     */
    set ExponentialSquared(value) {}


}