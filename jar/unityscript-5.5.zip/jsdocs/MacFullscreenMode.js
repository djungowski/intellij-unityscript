class MacFullscreenMode {


    /**
     * Fullscreen window.
     */
    get FullscreenWindow() {}

    /**
     * Fullscreen window.
     */
    set FullscreenWindow(value) {}

    /**
     * Fullscreen window with Dock and Menu bar.
     */
    get FullscreenWindowWithDockAndMenuBar() {}

    /**
     * Fullscreen window with Dock and Menu bar.
     */
    set FullscreenWindowWithDockAndMenuBar(value) {}


}