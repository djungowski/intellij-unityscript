class AvatarTarget {


    /**
     * The root, the position of the game object.
     */
    get Root() {}

    /**
     * The root, the position of the game object.
     */
    set Root(value) {}

    /**
     * The body, center of mass.
     */
    get Body() {}

    /**
     * The body, center of mass.
     */
    set Body(value) {}

    /**
     * The left foot.
     */
    get LeftFoot() {}

    /**
     * The left foot.
     */
    set LeftFoot(value) {}

    /**
     * The right foot.
     */
    get RightFoot() {}

    /**
     * The right foot.
     */
    set RightFoot(value) {}

    /**
     * The left hand.
     */
    get LeftHand() {}

    /**
     * The left hand.
     */
    set LeftHand(value) {}

    /**
     * The right hand.
     */
    get RightHand() {}

    /**
     * The right hand.
     */
    set RightHand(value) {}


}